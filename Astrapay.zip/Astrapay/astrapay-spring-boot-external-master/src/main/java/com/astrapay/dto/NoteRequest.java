package com.astrapay.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class NoteRequest {
    @NotBlank(message = "Title must not be blank")
    @Size(max = 200, message = "Title must be <= 200 characters")
    private String title;

    @Size(max = 5000, message = "Content must be <= 5000 characters")
    private String content;

    // getters & setters (tanpa Lombok)
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
}
