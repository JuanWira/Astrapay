package com.astrapay.service;

import com.astrapay.dto.NoteRequest;
import com.astrapay.dto.NoteResponse;
import com.astrapay.exception.NoteNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

@Service
public class NoteService {

    private static final Logger log = LoggerFactory.getLogger(NoteService.class);

    private final Map<Long, NoteResponse> notes = new ConcurrentHashMap<>();
    private final AtomicLong idCounter = new AtomicLong(0);

    public List<NoteResponse> getAllNotes() {
        log.info("Fetching all notes");
        return notes.values().stream()
                .sorted(Comparator.comparing(NoteResponse::getCreatedAt).reversed())
                .collect(Collectors.toList());
    }

    public NoteResponse getNoteById(Long id) {
        log.info("Fetching note id={}", id);
        NoteResponse note = notes.get(id);
        if (note == null) {
            throw new NoteNotFoundException("Note with id=" + id + " not found");
        }
        return note;
    }

    public NoteResponse createNote(NoteRequest request) {
        log.info("Creating new note title={}", request.getTitle());

        NoteResponse note = new NoteResponse();
        note.setId(idCounter.incrementAndGet());
        note.setTitle(request.getTitle());
        note.setContent(request.getContent());
        note.setCreatedAt(Instant.now());
        note.setUpdatedAt(Instant.now());

        notes.put(note.getId(), note);
        return note;
    }

    public void deleteNote(Long id) {
        log.info("Deleting note id={}", id);
        NoteResponse removed = notes.remove(id);
        if (removed == null) {
            throw new NoteNotFoundException("Note with id=" + id + " not found");
        }
    }
}
