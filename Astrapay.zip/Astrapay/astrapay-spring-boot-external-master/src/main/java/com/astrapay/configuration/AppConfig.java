package com.astrapay.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.time.Clock;

@Configuration
public class AppConfig {

    /**
     * Bean untuk HTTP client bawaan Spring.
     * Bisa dipakai kalau service butuh call ke API eksternal.
     */
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    /**
     * Bean Clock untuk mengambil waktu.
     * Berguna kalau suatu saat butuh test yang konsisten.
     */
    @Bean
    public Clock clock() {
        return Clock.systemUTC();
    }

    /**
     * CORS config supaya front-end (Angular di port 4200)
     * bisa akses API Spring Boot.
     */
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/api/**")
                        .allowedOrigins("http://localhost:4200")
                        .allowedMethods("GET","POST","DELETE","OPTIONS")
                        .allowCredentials(false);
            }
        };
    }
}
