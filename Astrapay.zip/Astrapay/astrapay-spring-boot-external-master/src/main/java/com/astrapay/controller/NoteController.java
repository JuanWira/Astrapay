package com.astrapay.controller;

import com.astrapay.dto.NoteRequest;
import com.astrapay.dto.NoteResponse;
import com.astrapay.exception.NoteNotFoundException;
import com.astrapay.service.NoteService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/notes")
@Api(value = "NoteController", tags = {"Notes API"})
@Slf4j
@Validated
public class NoteController {

    private final NoteService noteService;

    public NoteController(NoteService noteService) {
        this.noteService = noteService;
    }

    @GetMapping
    @ApiOperation(value = "Get All Notes")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = NoteResponse.class, responseContainer = "List")
    })
    public ResponseEntity<List<NoteResponse>> listNotes() {
        return ResponseEntity.ok(noteService.getAllNotes());
    }

    @GetMapping("/{id}")
    @ApiOperation(value = "Get Note by Id")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = NoteResponse.class),
            @ApiResponse(code = 404, message = "Note Not Found")
    })
    public ResponseEntity<?> getNoteById(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(noteService.getNoteById(id));
        } catch (NoteNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @PostMapping
    @ApiOperation(value = "Create Note")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Created", response = NoteResponse.class),
            @ApiResponse(code = 400, message = "Validation Error")
    })
    public ResponseEntity<NoteResponse> createNote(@Valid @RequestBody NoteRequest request) {
        NoteResponse created = noteService.createNote(request);
        URI location = URI.create("/api/v1/notes/" + created.getId());
        return ResponseEntity.created(location).body(created);
    }

    @DeleteMapping("/{id}")
    @ApiOperation(value = "Delete Note")
    @ApiResponses(value = {
            @ApiResponse(code = 204, message = "No Content"),
            @ApiResponse(code = 404, message = "Note Not Found")
    })
    public ResponseEntity<?> deleteNote(@PathVariable Long id) {
        try {
            noteService.deleteNote(id);
            return ResponseEntity.noContent().build();
        } catch (NoteNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}
