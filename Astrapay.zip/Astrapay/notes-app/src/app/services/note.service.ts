import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface NoteRequest {
  title: string;
  content?: string;
}

export interface NoteResponse {
  id: number;
  title: string;
  content: string;
  createdAt: string; // ISO date string dari backend
  updatedAt: string;
}

@Injectable({ providedIn: 'root' })
export class NoteService {
  private apiUrl = 'http://localhost:8000/api/v1/notes'; // sesuaikan port backend

  constructor(private http: HttpClient) {}

  getAll(): Observable<NoteResponse[]> {
    return this.http.get<NoteResponse[]>(this.apiUrl);
  }

  create(note: NoteRequest): Observable<NoteResponse> {
    return this.http.post<NoteResponse>(this.apiUrl, note);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
