export interface Note {
  id: number;
  content: string;
}
