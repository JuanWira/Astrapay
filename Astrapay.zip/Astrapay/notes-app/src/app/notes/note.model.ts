export interface Note {
  id: number;
  content: string;
  createdAt: string; // ISO string dari backend
}
