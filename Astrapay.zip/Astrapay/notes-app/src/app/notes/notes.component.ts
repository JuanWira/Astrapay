import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NoteService, NoteRequest, NoteResponse } from '../services/note.service';

@Component({
  selector: 'app-notes',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.css']
})
export class NotesComponent implements OnInit {
  notes: NoteResponse[] = [];
  newNote: NoteRequest = { title: '', content: '' };
  errorMessage = '';

  constructor(private noteService: NoteService) {}

  ngOnInit(): void {
    this.loadNotes();
  }

  loadNotes(): void {
    this.errorMessage = '';
    this.noteService.getAll().subscribe({
      next: (data: NoteResponse[]) => this.notes = data,
      error: () => this.errorMessage = 'Gagal memuat notes'
    });
  }

  addNote(): void {
    this.errorMessage = '';
    const title = (this.newNote.title || '').trim();
    const content = (this.newNote.content || '').trim();
    if (!title) {
      this.errorMessage = 'Title tidak boleh kosong';
      return;
    }
    const payload: NoteRequest = { title, content };

    this.noteService.create(payload).subscribe({
      next: (note: NoteResponse) => {
        this.notes = [note, ...this.notes];
        this.newNote = { title: '', content: '' };
      },
      error: (err: any) => {
        this.errorMessage = err?.error?.message || 'Gagal menambahkan note';
      }
    });
  }

  deleteNote(id: number): void {
    this.errorMessage = '';
    this.noteService.delete(id).subscribe({
      next: () => this.notes = this.notes.filter(n => n.id !== id),
      error: () => this.errorMessage = 'Gagal menghapus note'
    });
  }
}
